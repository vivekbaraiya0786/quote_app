class DataBaseCheckModel {
  bool isInsert;

  DataBaseCheckModel({
    required this.isInsert,
  });
}

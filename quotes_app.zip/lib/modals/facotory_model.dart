class FavoriteModel {
  int id;
  String quotes;
  String author;
  int favorite;

  FavoriteModel({
    required this.id,
    required this.quotes,
    required this.author,
    required this.favorite,
  });
}
